# Academia Legend - Dance Academy Website

A complete website for a dance academy built with HTML, CSS, PHP, JavaScript, JSON, and Bootstrap.

## Features

- **Responsive Design**: Fully responsive website using Bootstrap 5
- **Dynamic Content**: Classes and instructors loaded from JSON files
- **Contact System**: PHP-powered contact form with email notifications
- **Enrollment System**: Online class enrollment with admin management
- **Admin Dashboard**: Complete admin interface for managing enrollments and contacts
- **Image Gallery**: Interactive gallery with modal views
- **Smooth Animations**: CSS animations and scroll effects
- **Modern UI**: Clean, professional design with custom styling

## File Structure

```
ProyectoVanessa/
├── index.html              # Main homepage
├── contact.php             # Contact form handler
├── enroll.php              # Enrollment form handler
├── admin.php               # Admin dashboard
├── assets/
│   ├── css/
│   │   └── style.css       # Custom styles
│   └── js/
│       └── main.js         # JavaScript functionality
├── data/
│   ├── classes.json        # Dance classes data
│   └── instructors.json    # Instructors data
├── logs/                   # Contact form logs
└── images/
    ├── IMG_2159.png        # Hero/Ballet images
    ├── IMG_2160.png        # Contemporary dance
    ├── IMG_2161.png        # Jazz dance
    ├── IMG_2162.png        # Hip hop
    ├── IMG_2163.png        # Salsa/Latin
    ├── IMG_2164.png        # Flamenco
    └── IMG_2165.png        # Kids dance
```

## Technologies Used

- **HTML5**: Semantic markup structure
- **CSS3**: Custom styles with animations and responsive design
- **Bootstrap 5**: UI framework for responsive layout and components
- **JavaScript**: Interactive functionality and AJAX
- **PHP**: Server-side form processing and admin functionality
- **JSON**: Data storage for classes and instructors
- **Font Awesome**: Icons
- **Google Fonts**: Typography (Poppins, Dancing Script)

## Setup Instructions

1. **Web Server**: Upload files to a web server with PHP support
2. **Email Configuration**: Edit `contact.php` to configure SMTP settings
3. **Admin Access**: Change admin credentials in `admin.php`
4. **File Permissions**: Ensure write permissions for `data/` and `logs/` directories

## Class Types Offered

- Ballet Clásico (Classical Ballet)
- Danza Contemporánea (Contemporary Dance)
- Jazz Moderno (Modern Jazz)
- Hip Hop
- Salsa y Bachata
- Flamenco
- Danza para Niños (Kids Dance)
- Pre-Profesional (Pre-Professional)

## Features Overview

### Homepage (index.html)
- Hero carousel with academy images
- About section with academy information
- Dynamic classes section loaded from JSON
- Instructors showcase
- Image gallery with modal views
- Contact form with validation
- Responsive navigation

### Contact System (contact.php)
- Form validation and sanitization
- Email notifications to both customer and admin
- Automatic response with academy information
- Logging system for submissions

### Enrollment System (enroll.php)
- Class capacity management
- Student information collection
- Email confirmations
- Admin notifications

### Admin Dashboard (admin.php)
- Statistics overview
- Enrollment management
- Contact message review
- Class information display
- Simple authentication system

### Interactive Features
- Smooth scrolling navigation
- Animated elements on scroll
- Image gallery with lightbox
- Form validation and AJAX submission
- Responsive design for all devices

## Customization

### Colors
The website uses a custom color scheme defined in CSS variables:
- Primary: #ff6b6b (coral)
- Secondary: #4ecdc4 (teal)
- Accent: #ffe66d (yellow)

### Content
- Update `data/classes.json` to modify class offerings
- Update `data/instructors.json` to change instructor information
- Replace images with academy-specific photos
- Modify text content in HTML files

### Styling
- Custom styles in `assets/css/style.css`
- Bootstrap classes used throughout for responsive layout
- CSS animations and transitions for modern feel

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Contact Information

For questions about this website template:
- Built for Academia Legend
- Responsive design optimized for dance academy needs
- Professional contact and enrollment systems included

## License

This project is custom-built for Academia Legend. Modify as needed for your academy's requirements.